import math                     # self-explanatory
import pandas as pd             # untuk list dan melakukan manipulasi vektor
from math import pi, sqrt       # mendeklarasikan 

df = pd.read_csv("voice.csv")   # membaca data dari file voice.csv
print df                        # menampilkan seluruh kolom dari file voice.csv

A_train1 = df[475:1584]
A_train2 = df[2059:3168]
A_test1  = df[0:475]
A_test2  = df[1584:2059]

X_train1 = pd.concat([A_train1,A_train2])
X_test1  = pd.concat([A_test1,A_test2])


# MEMISAHKAN DATA MALE DENGAN FEMALE
male = X_train1[X_train1['label']=='male']
female = X_train1[X_train1['label']=='female']

# DROP COLUMN YANG TIDAK DIGUNAKAN
x_label = X_train1.drop(['meanfreq','sd','centroid','dfrange','label'],axis=1) 

# MEMBUAT LIST MEAN DAN STANDAR DEVIASI
male_mean = []                      
for i in x_label.columns:               #looping untuk menghitung nilai mean dari label "male"
    male_mean.append(male[i].mean())
    
male_std = []
for i in x_label.columns:               #looping untuk menghitung nilai standar deviasi dari label "male"
    male_std.append(male[i].std())

female_mean = []
for i in x_label.columns:               #looping untuk menghitung nilai mean dari label "female"
    female_mean.append(female[i].mean())

female_std = []
for i in x_label.columns:               #looping untuk menghitung nilai standar deviasi dari label "female"
   female_std.append(female[i].std())

print male_mean, ('\n')     # menampilkan nilai mean "male" tiap atribut
print male_std, ('\n')      # menampilkan nilai standar deviasi "male" tiap atribut
print female_mean, ('\n')   # menampilkan nilai mean "female" tiap atribut
print female_std, ('\n')    # menampilkan nilai standar deviasi "female" tiap atribut

# MEMBUAT FUNGSI PERHITUNGAN PROBABILITAS MALE DAN FEMALE
def impute_p_male(cols):
    p_total = 1                                 # inisialisasi variabel p_total
    for i in range (len(x_label.columns)):      # looping untuk semua kolom
        p = (1/(sqrt(2*pi*(male_std[i]**2))))**(((cols[i]-male_mean[i])**2)/(2*(male_std[i]**2)))        # rumus fungsi Gaussian
        p_total = p_total*p                     # looping untuk menghitung probabilitas gender male
    return -p_total*0.5                         # hasil akhir probabilitas male

def impute_p_female(cols):
    p_total = 1                                 # inisialisasi variabel p_total
    for i in range (len(x_label.columns)):      # looping untuk semua kolom
        p = (1/(sqrt(2*pi*(female_std[i]**2))))**(((cols[i]-female_mean[i])**2)/(2*(female_std[i]**2)))  # rumus fungsi Gaussian
        p_total = p_total*p                     # looping untuk menghitung probabilitas
    return -p_total*0.5                         # hasil akhir probabilitas female

# MENGISI KOLOM HASIL AKHIR PROBABILITAS MALE DAN FEMALE
X_test1['p_male']=X_test1[x_label.columns.tolist()].apply(impute_p_male,axis=1)
X_test1['p_female']=X_test1[x_label.columns.tolist()].apply(impute_p_female,axis=1)

# MENENTUKAN HASIL PREDIKSI
def impute_pred(cols):
    p_male = cols[0]        # data pada kolom probabilitas male
    p_female = cols[1]      # data pada kolom probabilitas female 

    if p_male>p_female:     # jika nilai probabilitas male > probabilitas female, maka
        return 'male'       # hasil prediction : "male"
    else:                   # jika nilai probabilitas male < probabilitas female
        return 'female'     # hasil prediction : "female"

# MENGISI KOLOM HASIL AKHIR PREDIKSI BERDASARKAN PERHITUNGAN
X_test1['prediction']=X_test1[['p_male','p_female']].apply(impute_pred,axis=1)
print X_test1['prediction']  # menampilkan kolom hasil prediction

# MENGHITUNG AKURASI
def impute_acc(cols):
    label = cols[0]                             # data pada kolom label
    pred = cols[1]                              # data pada kolom prediction
    if (label=='male') & (pred=='male'):        # jika nilai label dan prediction sama-sama "male", maka
        return 'TM'                             # nilai menjadi "TM" (True Male)
    elif (label=='female') & (pred=='female'):  # jika nilai label dan prediction sama-sama "female", maka
        return 'TF'                             # nilai menjadi "TF" (True Female)
    elif (label=='male') & (pred!='male'):      # jika nilai label "male "dan prediction berbeda, maka
        return 'FM'                             # nilai menjadi "FM" (False Male)
    else:                                       # jika nilai label "female "dan prediction berbeda, maka
        return 'FF'                             # nilai menjadi "FF" (False False)
                  
# MENGISI KOLOM AKURASI
X_test1['acc']=X_test1[['label','prediction']].apply(impute_acc,axis=1)

TM = X_test1[X_test1['acc']=='TM']['label'].count()       # menghitung jumlah label "male" yang sesuai prediction      
TF = X_test1[X_test1['acc']=='TF']['label'].count()       # menghitung jumlah label "female" yang sesuai prediction
FM = X_test1[X_test1['acc']=='FM']['label'].count()       # menghitung jumlah label "male" yang tidak sesuai prediction
FF = X_test1[X_test1['acc']=='FF']['label'].count()       # menghitung jumlah label "female" yang tidak sesuai prediction
total = TM + TF + FM + FF                                 # menghitung jumlah data total (3168)
x = TM + TF                                               # menghitung jumlah data yang benar
accuracy = (float(x)/float(total))*100                    # menghitung akurasi


print X_test1                                   # menampilkan seluruh kolom (termasuk label, prediction, dan akurasi)
print ("True Male    :"), TM                    # menampilkan jumlah label "male" yang benar
print ("True Female  :"), TF                    # menampilkan jumlah label "female" yang benar    
print ("False Male   :"), FM                    # menampilkan jumlah label "male" yang salah
print ("False Female :"), FF                    # menampilkan jumlah label "female" yang salah
print ("Total        :"), total, ('\n')         # menampilkan jumlah total data
print ("Accuracy         :"), accuracy, ("%")   # menampilkan hasil akurasi algoritma Naive Bayes

#RECALL
recall_male = (float(TM)/float(TM + FF))*100    # menghitung recall male
recall_female = (float(TF)/float(TF + FM))*100  # menghitung recall female
print ("Recall Male      :"), recall_male, ("%")  # menampilkan hasil recall male
print ("Recall Female    :"), recall_female, ("%")# menampilkan hasil recall female

#PRECISION
prec_male = (float(TM)/float(TM + FM))*100      # menghitung precision male
prec_female = (float(TF)/float(TF + FF))*100    # menghitung precision female
print ("Precision Male   :"), prec_male, ("%")  # menampilkan hasil precision male
print ("Precision Female :"), prec_female, ("%")# menampilkan hasil precision female 
