import random # to randomize the training dataset
import math # self-explanatory
import pprint # to pretty print our initial non-panda dataset
import pandas as pd # to list and do vector manipulation

df = pd.read_csv("voice.csv")
print df

df

from sklearn import preprocessing
le = preprocessing.LabelEncoder()

from sklearn.naive_bayes import GaussianNB

#Create a Gaussian Classifier
model = GaussianNB()

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df.drop(labels=['label','centroid','dfrange','meanfreq','sd'],axis=1), df['label'], test_size=0.3, random_state=101)
model.fit(X_train,y_train)
model_pred = model.predict(X_test)

from sklearn.metrics import classification_report,confusion_matrix
print(confusion_matrix(y_test,model_pred))
print('\n')
print(classification_report(y_test,model_pred))

from sklearn.model_selection import cross_val_score
X = df.drop(labels=['label','centroid','dfrange','meanfreq','sd'],axis=1)
y = df['label']
print(cross_val_score(model, X, y, cv=5))
